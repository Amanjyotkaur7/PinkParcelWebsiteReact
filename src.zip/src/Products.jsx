import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom'; // Importing useParams from react-router-dom
import './Products.css';

const Products = () => {
  const { productId } = useParams(); // Getting productId from URL
  console.log('Product ID from URL:', productId);
  
  const [product, setProduct] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [newReview, setNewReview] = useState('');
  const [error, setError] = useState('');

  // Fetch product details and reviews when the component mounts
  useEffect(() => {
    // Fetch product details
    fetch(`http://localhost/your-php-backend-folder/getProduct.php?productId=${productId}`)
      .then(response => response.json()) // Convert the response to JSON
      .then(data => {
        if (data.product) { // Now check if `data.product` exists
          setProduct(data.product);
          console.log(data.product);
        } else {
          setError('Product not found');
        }
      })
      .catch(error => {
        console.error('Error fetching product details:', error);
        setError('Error fetching product details');
      });

    // Fetch reviews for the product
    fetch(`http://localhost/your-php-backend-folder/getReviews.php?productId=${productId}`)
      .then(response => response.json()) // Convert the response to JSON
      .then(data => {
        if (data.reviews) {
          setReviews(data.reviews);
        }
      })
      .catch(error => console.error('Error fetching reviews:', error));
  }, [productId]);

  // Handle the review submission
  const handleReviewSubmit = () => {
    // Simple form validation for empty review
    if (!newReview.trim()) {
      setError('Review cannot be empty');
      return;
    }

    setError('');

    // POST the review to the backend
    fetch('http://localhost/your-php-backend-folder/submitReview.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        productId,
        review: newReview,
      }),
    })
      .then(response => response.json()) // Convert the response to JSON
      .then(data => {
        if (data.success) {
          setReviews([...reviews, newReview]); // Add the new review to the list
          setNewReview(''); // Clear the review input field
        } else {
          setError(data.error || 'Failed to submit review');
        }
      })
      .catch(error => {
        console.error('Error submitting review:', error);
        setError('Error submitting review');
      });
  };

  return (
    <div className="product-detail-container">
      {/* Display error if any */}
      {error && <div className="error-message">{error}</div>}

      {/* Product Details */}
      {product ? (
        <div>
          <h2 className="product-name">{product.name}</h2>
          <p className="product-price">${product.price}</p>
          <p className="product-description">{product.description}</p>

          {/* Bootstrap Carousel for product images */}
          <div id="productCarousel" className="carousel slide" data-bs-ride="carousel">
            <div className="carousel-inner">
              {product.images && product.images.map((image, index) => (
                <div className={`carousel-item ${index === 0 ? 'active' : ''}`} key={index}>
                  <img src={`http://localhost/your-php-backend-folder/images/${image}`} className="d-block w-100" alt="Product" />
                </div>
              ))}
            </div>
            <button className="carousel-control-prev" type="button" data-bs-target="#productCarousel" data-bs-slide="prev">
              <span className="carousel-control-prev-icon" aria-hidden="true"></span>
              <span className="visually-hidden">Previous</span>
            </button>
            <button className="carousel-control-next" type="button" data-bs-target="#productCarousel" data-bs-slide="next">
              <span className="carousel-control-next-icon" aria-hidden="true"></span>
              <span className="visually-hidden">Next</span>
            </button>
          </div>
        </div>
      ) : (
        <p>Loading product details...</p>
      )}

      {/* Review Section */}
      <div className="review-section">
        <h2>Customer Reviews</h2>

        {reviews.length > 0 ? (
          reviews.map((review, index) => (
            <div className="review-item" key={index}>
              <p>{review}</p>
            </div>
          ))
        ) : (
          <p>No reviews yet.</p>
        )}

        {/* Review Form */}
        <textarea
          value={newReview}
          onChange={(e) => setNewReview(e.target.value)}
          placeholder="Write a review"
          rows="4"
        />
        <button onClick={handleReviewSubmit}>Submit Review</button>
      </div>
    </div>
  );
};

export default Products;
