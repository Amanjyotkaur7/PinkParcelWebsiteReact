import React from "react";
import "./GynacConsultation.css";

const GynacConsultation = () => {
  return (
    <div className="gynac-container">
      {/* Header Section */}
      <div className="gynac-header">
        <h1>Gynac Consultation</h1>
        <p>Expert advice for women’s health and wellness.</p>
      </div>

      {/* Why Consult Section */}
      <div className="gynac-content">
        <div className="gynac-info">
          <h2>Why Consult Us?</h2>
          <ul className="benefits-list">
            <li>Personalized healthcare tailored to your needs.</li>
            <li>Certified and experienced gynecologists.</li>
            <li>Confidential and comfortable consultations.</li>
            <li>Support for menstrual health, pregnancy, and menopause.</li>
          </ul>
        </div>
        <div className="gynac-action">
          <button className="book-now-btn">Book Your Appointment</button>
        </div>
      </div>

      {/* Testimonials Section */}
      <div className="gynac-testimonials">
        <h2>What Our Clients Say</h2>
        <div className="testimonial">
          <p>"The consultation helped me understand my health better. Highly recommended!"</p>
          <span>- Priya, 29</span>
        </div>
        <div className="testimonial">
          <p>"I felt comfortable and safe discussing my issues. Great experience!"</p>
          <span>- Ananya, 35</span>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="gynac-faq">
        <h2>Frequently Asked Questions</h2>
        <div className="faq-item">
          <h3>What can I discuss in a consultation?</h3>
          <p>You can discuss any gynecological or reproductive health concerns you have.</p>
        </div>
        <div className="faq-item">
          <h3>How long does a consultation take?</h3>
          <p>Each session typically lasts 30-45 minutes.</p>
        </div>
        <div className="faq-item">
          <h3>Is my information confidential?</h3>
          <p>Yes, all consultations are strictly confidential.</p>
        </div>
      </div>

      {/* Image Section */}
      <div className="gynac-image">
        <img
          src="https://via.placeholder.com/400x250"
          alt="Consultation illustration"
        />
      </div>
    </div>
  );
};

export default GynacConsultation;
