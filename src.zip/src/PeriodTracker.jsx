import React, { useState } from 'react';
import './PeriodTracker.css';

function PeriodTracker() {
    const [lastPeriod, setLastPeriod] = useState('');
    const [cycleLength, setCycleLength] = useState('');
    const [nextPeriod, setNextPeriod] = useState('');

    const handleCalculate = () => {
        if (!lastPeriod || !cycleLength || isNaN(cycleLength)) {
            alert('Please enter valid details!');
            return;
        }
        const lastDate = new Date(lastPeriod);
        const predictedDate = new Date(
            lastDate.setDate(lastDate.getDate() + parseInt(cycleLength, 10))
        );
        setNextPeriod(predictedDate.toISOString().split('T')[0]);
    };

    return (
        <div className="period-tracker">
            <h1>Period Tracker</h1>
            <div className="input-group">
                <label htmlFor="lastPeriod">Last Period Date:</label>
                <input
                    type="date"
                    id="lastPeriod"
                    value={lastPeriod}
                    onChange={(e) => setLastPeriod(e.target.value)}
                />
            </div>
            <div className="input-group">
                <label htmlFor="cycleLength">Average Cycle Length (days):</label>
                <input
                    type="number"
                    id="cycleLength"
                    value={cycleLength}
                    onChange={(e) => setCycleLength(e.target.value)}
                />
            </div>
            <button onClick={handleCalculate} className="calculate-btn">
                Calculate Next Period
            </button>
            {nextPeriod && (
                <div className="result">
                    <h2>Your Next Period Date: {nextPeriod}</h2>
                </div>
            )}
        </div>
    );
}

export default PeriodTracker;
